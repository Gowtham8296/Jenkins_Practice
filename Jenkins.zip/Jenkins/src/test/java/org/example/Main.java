package org.example;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.*;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

import java.time.Duration;


public class Main {
    public static void main(String[] args) {

        WebDriver driver;
        WebDriverWait wait;
        System.setProperty("webdriver.chrome.driver", "C:/Users/GowthamGR/Jenkins/chromedriver.exe");

        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        driver.get("https://www.flipkart.com/");

        try {
            WebElement closeButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='_2KpZ6l _2doB4z']")));
            closeButton.click();
        } catch (Exception e) {
        }

        WebElement searchBox = driver.findElement(By.name("q"));
        searchBox.sendKeys("laptop");
        searchBox.submit();

        WebElement firstResult = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div._1AtVbE > a")));
        firstResult.click();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.quit();
    }

}
